/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twittermongodbapp;

import com.mongodb.BasicDBList;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.DBCursor;

import twitter4j.HashtagEntity;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.TwitterObjectFactory;
import twitter4j.URLEntity;
import twitter4j.UserMentionEntity;

/**
 *
 * @author aristeidis
 */
public class SaveTweets {
    static public void saveTweets(DB db,twitter4j.Twitter twitter) throws TwitterException{
        DBCollection collection = db.getCollection("collection");
        DBCollection savedCollection = db.getCollection("savedCollection");
        BasicDBObject document0 = new BasicDBObject();
        savedCollection.remove(document0);
        Status savedTweet ;
        
        //Read Tweets from Database
        System.out.println("Saved tweets: ");
         DBCursor cursor = collection.find();
         while (cursor.hasNext()) {
             DBObject obj = cursor.next(); 
             savedTweet = TwitterObjectFactory.createStatus(obj.toString());
            System.out.println("@" + savedTweet.getUser().getScreenName() + " ------- " + savedTweet.getText());
            
                     
                     String name = savedTweet.getUser().getScreenName();
            
                     String tweetText = savedTweet.getText();
                     
                      HashtagEntity[] hashtagsEntities =savedTweet.getHashtagEntities();
                      BasicDBList hashtags = new BasicDBList();
                      for (int i = 0; i < hashtagsEntities.length; i++) {
                        hashtags.add(new BasicDBObject("hashtag",hashtagsEntities[i].getText()));
                        System.out.println("Hashtag: " + hashtagsEntities[i].getText());
                       
                      }
                      
                      int flag =1;
                      BasicDBList mentions = new BasicDBList();
                     UserMentionEntity[] mentionEntities = savedTweet.getUserMentionEntities();
                     if(savedTweet.isRetweet()){
                         for (int i = 1; i < mentionEntities.length; i++) {
                        mentions.add(new BasicDBObject("mention",mentionEntities[i].getText()));
                        System.out.println("Mention: " + mentionEntities[i].getText());
                       
                      }
                     }else{
                         for (int i = 0; i < mentionEntities.length; i++) {
                        mentions.add(new BasicDBObject("mention",mentionEntities[i].getText()));
                        System.out.println("Mention: " + mentionEntities[i].getText());
                       
                      }
                     }
                     BasicDBList shortURLS = new BasicDBList();
                      BasicDBList wholeURLS = new BasicDBList();
                      URLEntity[] urlEntities = savedTweet.getURLEntities();
                       for (int i = 0; i < savedTweet.getURLEntities().length; i++) {
                        shortURLS.add(new BasicDBObject("shortURL",urlEntities[i].getURL()));
                          wholeURLS.add(new BasicDBObject("wholeURL",urlEntities[i].getDisplayURL()));
                          System.out.println("shortURL: " + urlEntities[i].getURL());
                          System.out.println("wholeURL: " + urlEntities[i].getDisplayURL());
                       }
                     
                      
                      String date = savedTweet.getCreatedAt().toString();
                      System.out.println("Date: " +date);
                    
                     Boolean rt=false;  
                    if(savedTweet.isRetweet()){ 
                        rt=true;
                    }
                    
                     BasicDBObject document = new BasicDBObject("name",name)
                     .append("tweetText",tweetText)
                     .append("Hashtags",hashtags) 
                     .append("Mentions",mentions)
                     .append("shortUrls",shortURLS)
                     .append("wholeUrls",wholeURLS)
                     .append("Date",date)
                     .append("IsReTweet",rt)
                     .append("tweet", obj.toString())
                      ;
                     savedCollection.insert(document);
         }
         System.out.println("Collected tweets :" + savedCollection.getCount()); 
    }
    
}
